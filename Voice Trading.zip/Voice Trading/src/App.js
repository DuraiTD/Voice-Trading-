import React, { useState, useEffect } from "react";
import { Route, Routes, Link, useNavigate } from "react-router-dom";
import SpeechRecognition, { useSpeechRecognition } from "react-speech-recognition";
import { Mic, MicOff, Home, Settings, User } from "lucide-react";

import "./App.css";

const TCSLogo = "https://logowiki.net/wp-content/uploads/imgp/TCS-Logo-1-2552.png";
const RelianceLogo = "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0b/Reliance_Industries_Logo.svg/1200px-Reliance_Industries_Logo.svg.png";

function App() {
  const [amount, setAmount] = useState(1000);
  const [shareValues, setShareValues] = useState({
    TCS: 0,
    RELIANCE: 0,
  });
  const [loading, setLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const navigate = useNavigate();
  const { finalTranscript, listening, resetTranscript } = useSpeechRecognition();
  const [speaking, setSpeaking] = useState(false);

  const sharePrices = {
    TCS: 1,
    RELIANCE: 2,
  };

  const processCommand = (command) => {
    setLoading(true); // Show loader when command starts processing
    setIsProcessing(true);
    const lowerCommand = command.toLowerCase();

    if (lowerCommand.includes("go to home")) {
      console.log("Navigating to Home");
      navigate("/");
    } else if (lowerCommand.includes("go to settings")) {
      console.log("Navigating to Settings");
      navigate("/settings");
    } else if (lowerCommand.includes("go to account")) {
      console.log("Navigating to Account");
      navigate("/account");
    }

    const tradeMatch = lowerCommand.match(/buy (\w+) (\d+)/);
    if (tradeMatch) {
      const companyName = tradeMatch[1].toUpperCase();
      const quantity = parseInt(tradeMatch[2], 10);

      if (sharePrices[companyName]) {
        const tradeCost = sharePrices[companyName] * quantity;

        if (amount >= tradeCost) {
          setAmount((prevAmount) => prevAmount - tradeCost);
          setShareValues((prevValues) => ({
            ...prevValues,
            [companyName]: prevValues[companyName] + quantity,
          }));
          console.log(`Successfully bought ${quantity} shares of ${companyName}`);
        } else {
          console.log("Not enough funds to complete the trade.");
        }
      } else {
        console.log("Invalid company name.");
      }
    }

    setTimeout(() => {
      setLoading(false); // Hide the loader after processing
      setIsProcessing(false);
      console.log("Finished processing command.");
      SpeechRecognition.stopListening(); // Stop listening
    }, 500); // No delay for loader or mic button
  };

  useEffect(() => {
    if (finalTranscript) {
      setSpeaking(true);
      console.log("Processing command:", finalTranscript);
      processCommand(finalTranscript);
      resetTranscript();
      setSpeaking(false);
    }
  }, [finalTranscript]);

  return (
    <div className="app">
      <nav className="nav-bar">
        <Link to="/" className="nav-link"><Home size={24} /> Home</Link>
        <Link to="/settings" className="nav-link"><Settings size={24} /> Settings</Link>
        <Link to="/account" className="nav-link"><User size={24} /> Account</Link>
      </nav>

      {/* Mic button to start speech recognition */}
      <button
        className={`mic-btn ${listening ? "active" : ""}`}
        onClick={() => {
          setIsProcessing(true); // Start processing when mic button is clicked
          SpeechRecognition.startListening({ continuous: true });
        }}
      >
        {listening ? <MicOff size={28} /> : <Mic size={28} />}
      </button>

      {/* Show loader below the mic button */}
      {listening && (
        <div className="loader-container">
          <div className="loader">
            <div></div>
            <div></div>
            <div></div>
            <div></div>
            <div></div>
          </div>
        </div>
      )}

      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="/account" element={<Account amount={amount} shareValues={shareValues} />} />
      </Routes>
    </div>
  );
}

function HomePage() {
  return <div className="page"><h1>🏠 Home Page</h1></div>;
}

function SettingsPage() {
  return <div className="page"><h1>⚙️ Settings Page</h1></div>;
}

function Account({ amount, shareValues }) {
  return (
    <div className="page">
      <h1>💰 Account Page</h1>
      <p>Total Amount: ${amount.toFixed(2)}</p>
      <h3>Your Shares:</h3>
      <table className="shares-table">
        <thead>
          <tr><th>Company</th><th>Shares</th><th>Status</th></tr>
        </thead>
        <tbody>
          <tr><td>TCS</td><td>{shareValues.TCS} shares</td><td>{shareValues.TCS > 0 ? "Held" : "No Shares"}</td></tr>
          <tr><td>Reliance</td><td>{shareValues.RELIANCE} shares</td><td>{shareValues.RELIANCE > 0 ? "Held" : "No Shares"}</td></tr>
        </tbody>
      </table>
    </div>
  );
}

export default App;
